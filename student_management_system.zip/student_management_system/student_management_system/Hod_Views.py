import base64
import io
from django.shortcuts import redirect,render,HttpResponse
from django.contrib.auth.decorators import login_required
from app.models import Course,Session_Year,Student,Staff,Subject,Staff_Notification,Staff_Leave,Staff_Feedback

from django.contrib.auth import get_user_model
from django.contrib import messages
from app.models import CustomUser
from django.contrib.auth import authenticate, login, logout
from django.conf import settings
import pyotp
import qrcode
from qrcode.main import make


@login_required(login_url="/")
def HOME(request):

    student_count   = Student.objects.all().count()
    staff_count     = Staff.objects.all().count()
    course_count    = Course.objects.all().count()
    subject_count   = Subject.objects.all().count()

    #For Chart
    student_male = Student.objects.filter(gender="Male").count()
    student_female = Student.objects.filter(gender="Female").count()

    context = {
        "student_count":student_count,'staff_count':staff_count,
        'course_count':course_count,'subject_count':subject_count,
        'student_male':student_male,'student_female':student_female
    }
    return render(request,'Hod/home.html',context)

# STUDENT MODULE
@login_required(login_url="/")
def ADD_STUDENT(request):
    course = Course.objects.all()
    session_year = Session_Year.objects.all()
    context = {
        'course':course,
        'session_year':session_year
    }
    if request.method == "POST":
        try:
            profile_pic = request.FILES.get('profile_pic')
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            email = request.POST.get('email')
            username = request.POST.get('username')
            password = request.POST.get('password')
            address = request.POST.get('address')
            gender = request.POST.get('gender')
            course_id = request.POST.get('course_id')
            session_year_id = request.POST.get('session_year_id')

            #validation
            if CustomUser.objects.filter(email=email).exists():
                messages.warning(request,"Email already taken")
                return redirect('add_student')
            elif CustomUser.objects.filter(username=username).exists():
                messages.warning(request,"Username already taken")
                return redirect('add_student')
            else:
                user = CustomUser(
                    first_name = first_name,
                    last_name=last_name,
                    email=email,
                    username=username,
                    profile_pic=profile_pic,
                    user_type='3'
                )
                user.set_password(password)
                user.save()

                #Student
                course = Course.objects.get(id=course_id)
                session_year = Session_Year.objects.get(id=session_year_id)
                student = Student(
                    admin=user,
                    address=address,
                    gender=gender,
                    course_id=course,
                    session_year_id=session_year
                )
                student.save()
                messages.success(request,"Student record save successfully")
                return redirect('view_student')
        except Exception as e:
            messages.error(request,str(e))
            return redirect('add_student')

    return render(request,'Hod/add_student.html',context)

@login_required(login_url="/")
def VIEW_STUDENT(request):
    student = Student.objects.all()
    context = {
        "student":student
    }
    return render(request,'Hod/view_student.html',context)

@login_required(login_url="/")
def EDIT_STUDENT(request,id):
    if id==None or id=="":
        messages.error(request,"ID is required")
        return redirect("view_student")

    try:
        student =Student.objects.get(id=id)
    except Student.DoesNotExist:
        messages.error(request, "Student data not exists")
        return redirect("view_student")

    course = Course.objects.all()
    session_year = Session_Year.objects.all()
    gender_list = ["Female", "Male", "Others"]

    context = {
        "student":student,
        "course":course,
        "gender_list":gender_list,
        "session_year":session_year
    }

    return render(request,'Hod/edit_student.html',context)

@login_required(login_url="/")
def UPDATE_STUDENT(request):
    if request.method == "POST":
        try:
            student_id = request.POST.get('student_id')
            profile_pic = request.FILES.get('profile_pic')
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            email = request.POST.get('email')
            password = request.POST.get('password')
            address = request.POST.get('address')
            gender = request.POST.get('gender')
            username = request.POST.get('username')
            course_id = request.POST.get('course_id')
            session_year_id = request.POST.get('session_year_id')

            try:
                user_obj =CustomUser.objects.get(id=int(student_id))
            except Exception as e:
                print(e)
                return redirect('view_student')

            user_obj.first_name = first_name
            user_obj.last_name = last_name
            user_obj.email = email
            user_obj.username = username

            if profile_pic!=None and profile_pic!="":
                user_obj.profile_pic = profile_pic

            if password!=None and password!="":
                user_obj.set_password(password)

            user_obj.save()

            student_obj = Student.objects.get(admin=int(student_id))
            student_obj.address = address
            student_obj.gender = gender

            course = Course.objects.get(id=course_id)
            student_obj.course_id=course

            session_year = Session_Year.objects.get(id=session_year_id)
            student_obj.session_year_id = session_year
            student_obj.save()

            messages.success(request,"Student record updated successfully")
            return redirect('view_student')
        except Exception as e:
            messages.error(request,str(e))
            return redirect('view_student')
    else:
        return redirect('view_student')

@login_required(login_url="/")
def DELETE_STUDENT(request,admin):
    student = CustomUser.objects.get(id=admin)
    student.delete()
    messages.success(request,"Record deleted successfully")
    return redirect('view_student')

# COURSE MODULE
@login_required(login_url="/")
def ADD_COURSE(request):
    if request.method == "POST":
        try:
            name = request.POST.get('name')
            course_obj = Course(name = name)
            course_obj.save()
            messages.success(request, "Course added successfully")
            return redirect('view_course')
        except Exception as e:
            messages.error(request, str(e))
            return redirect('view_course')

    return render(request, 'Hod/add_course.html')

@login_required(login_url="/")
def VIEW_COURSE(request):
    course_obj = Course.objects.all()
    context = {
        'course':course_obj
    }
    return render(request, 'Hod/view_course.html',context)

@login_required(login_url="/")
def EDIT_COURSE(request,id):
    course_obj = Course.objects.get(id=id)
    print(course_obj)
    context = {'course':course_obj}
    return render(request, 'Hod/edit_course.html', context)

@login_required(login_url="/")
def UPDATE_COURSE(request):
    if request.method == "POST":
        course_id = request.POST.get('course_id')
        name = request.POST.get('name')

        course_info = Course.objects.get(id=course_id)
        course_info.name = name
        course_info.save()
        messages.success(request, "Course updated successfully")
        return redirect('view_course')
    else:
        return redirect('edit_course')

@login_required(login_url="/")
def DELETE_COURSE(request,id):
    try:
        course_info = Course.objects.get(id=id)
        course_info.delete()
        messages.success(request, "Course deleted successfully")
        return redirect('view_course')
    except Exception as e:
        messages.error(request, str(e))
        return redirect('view_course')

# STAFF MODULE
@login_required(login_url="/")
def ADD_STAFF(request):
    if request.method == 'POST':
        try:
            profile_pic = request.FILES.get('profile_pic')
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            email = request.POST.get('email')
            username = request.POST.get('username')
            password = request.POST.get('password')
            address = request.POST.get('address')
            gender = request.POST.get('gender')

            #validation
            if CustomUser.objects.filter(email=email).exists():
                messages.warning(request,"Email already taken")
                return redirect('add_staff')
            elif CustomUser.objects.filter(username=username).exists():
                messages.warning(request,"Username already taken")
                return redirect('add_staff')
            else:
                user = CustomUser(
                    first_name = first_name,
                    last_name=last_name,
                    email=email,
                    username=username,
                    profile_pic=profile_pic,
                    user_type='2'
                )
                user.set_password(password)
                user.save()

                #Student
                student = Staff(
                    admin=user,
                    address=address,
                    gender=gender
                )
                student.save()
                messages.success(request,"Staff record save successfully")
                return redirect('view_staff')
        except Exception as e:
            messages.error(request,str(e))
            return redirect('add_staff')

    return render(request, 'Hod/add_staff.html')

@login_required(login_url="/")
def VIEW_STAFF(request):
    staff = Staff.objects.all()
    context = {
        "staff": staff
    }
    return render(request, 'Hod/view_staff.html', context)

@login_required(login_url="/")
def EDIT_STAFF(request,id):
    staff = Staff.objects.get(id=id)
    gender_list = ["Female", "Male", "Others"]
    context = {
        "staff": staff,
        'gender_list':gender_list
    }
    return render(request, 'Hod/edit_staff.html', context)

@login_required(login_url="/")
def UPDATE_STAFF(request):
    if request.method == "POST":
        try:
            staff_id = request.POST.get('staff_id')
            profile_pic = request.FILES.get('profile_pic')
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            email = request.POST.get('email')
            password = request.POST.get('password')
            address = request.POST.get('address')
            gender = request.POST.get('gender')
            username = request.POST.get('username')

            try:
                user_obj = CustomUser.objects.get(id=int(staff_id))
            except Exception as e:
                print(e)
                return redirect('view_staff')

            user_obj.first_name = first_name
            user_obj.last_name = last_name
            user_obj.email = email
            user_obj.username = username

            if profile_pic != None and profile_pic != "":
                user_obj.profile_pic = profile_pic

            if password != None and password != "":
                user_obj.set_password(password)

            user_obj.save()

            staff_obj = Staff.objects.get(admin=int(staff_id))
            staff_obj.address = address
            staff_obj.gender = gender
            staff_obj.save()

            messages.success(request, "Staff record updated successfully")
            return redirect('view_staff')
        except Exception as e:
            messages.error(request, str(e))
            return redirect('view_staff')
    else:
        return redirect('view_staff')

@login_required(login_url="/")
def DELETE_STAFF(request,id):
    staff = CustomUser.objects.get(id=id)
    staff.delete()
    messages.success(request, "Staff deleted successfully")
    return redirect('view_staff')

# SUBJECT MODULE
@login_required(login_url="/")
def ADD_SUBJECT(request):
    if request.method== "POST":
        try:
            name = request.POST.get('name')
            course_id = request.POST.get('course_id')
            staff_id = request.POST.get('staff_id')

            course = Course.objects.get(id=course_id)
            staff = Staff.objects.get(id=staff_id)
            subject = Subject(
                name=name,
                course = course,
                staff = staff
            )
            subject.save()
            messages.success(request,"Subject added successfully")
            return redirect('view_subject')
        except Exception as e:
            messages.error(request, str(e))
            return redirect('add_subject')
    else:
        course = Course.objects.all()
        staff = Staff.objects.all()
        context = {'course': course,'staff': staff  }
        return render(request, 'Hod/add_subject.html', context)

@login_required(login_url="/")
def VIEW_SUBJECT(request):
    subject_obj = Subject.objects.all()
    context = {"subject":subject_obj}
    return render(request, 'Hod/view_subject.html', context)

@login_required(login_url="/")
def EDIT_SUBJECT(request,id):
    subject = Subject.objects.get(id=id)
    course = Course.objects.all()
    staff = Staff.objects.all()
    context = {'course': course,'staff': staff,'subject':subject}
    return render(request, 'Hod/edit_subject.html', context)

@login_required(login_url="/")
def UPDATE_SUBJECT(request):
    if request.method == "POST":
        try:
            subject_id = request.POST.get('subject_id')
            name = request.POST.get('name')
            course_id = request.POST.get('course_id')
            staff_id = request.POST.get('staff_id')

            course = Course.objects.get(id=course_id)
            staff = Staff.objects.get(id=staff_id)
            subject_obj = Subject.objects.get(id=subject_id)
            subject_obj.name = name
            subject_obj.course = course
            subject_obj.staff = staff
            subject_obj.save()
            messages.success(request,"Subject updated successfully")
            return redirect("view_subject")
        except Exception as e:
            messages.error(request, str(e))
            return redirect('edit_subject')
    else:
        messages.error(request,"Invalid request method")
        return redirect('edit_subject')

@login_required(login_url="/")
def DELETE_SUBJECT(request,id):
    try:
        subject = Subject.objects.filter(id=id)
        subject.delete()
        messages.success(request, "Subject deleted successfully")
        return redirect('view_subject')
    except Exception as e:
        messages.error(request, str(e))
        return redirect('view_subject')

# SESSION MODULE
@login_required(login_url="/")
def ADD_SESSION(request):
    if request.method == "POST":
        session_start = request.POST.get('session_start')
        session_end = request.POST.get('session_end')

        session_obj = Session_Year(
            session_start=session_start,
            session_end=session_end
        )
        session_obj.save()
        messages.success(request,"Session record save successfully")
        return redirect('view_session')

    else:
        return render(request, 'Hod/add_session.html')

@login_required(login_url="/")
def VIEW_SESSION(request):
    session = Session_Year.objects.all()
    context = {'session':session}
    return render(request, 'Hod/view_session.html',context)

@login_required(login_url="/")
def EDIT_SESSION(request,id):
    session = Session_Year.objects.filter(id=id)
    context = {'session': session}
    return render(request, 'Hod/edit_session.html', context)

@login_required(login_url="/")
def UPDATE_SESSION(request):
    if request.method == "POST":
        session_id = request.POST.get('session_id')
        session_start = request.POST.get('session_start')
        session_end = request.POST.get('session_end')

        session_obj = Session_Year.objects.get(id=session_id)
        session_obj.session_start = session_start
        session_obj.session_end = session_end
        session_obj.save()

        messages.success(request, "Session update successfully")
        return redirect("view_session")
    else:
        messages.error(request, "Invalid request")
        return redirect('view_session')

@login_required(login_url="/")
def DELETE_SESSION(request,id):
    try:
        session_obj = Session_Year.objects.get(id=id)
        session_obj.delete()
        messages.success(request, "Session deleted successfully")
        return redirect("view_session")
    except Exception as e:
        messages.error(request, str(e))
        return redirect('view_session')

# Notification
@login_required(login_url="/")
def STAFF_SEND_NOTIFICATION(request):
    staff = Staff.objects.all()
    notify = Staff_Notification.objects.all().order_by('-id')[0:5]
    context = {"staff":staff,'see_notification':notify}
    return render(request,'Hod/staff_notification.html',context)

@login_required(login_url="/")
def SAVE_STAFF_NOTIFICATION(request):
    if request.method == "POST":
        staff_id = request.POST.get('staff_id')
        msg = request.POST.get('message')

        staff = Staff.objects.get(admin=staff_id)
        store_obj = Staff_Notification(
            staff_id=staff,
            message = msg
        )
        store_obj.save()
        messages.success(request, "Notification sent successfully")
        return redirect("staff_send_notification")
    else:
        return redirect("staff_send_notification")

@login_required(login_url="/")
def STAFF_LEAVE_VIEW(request):
    staff_leave = Staff_Leave.objects.all().order_by('-id')
    context ={"staff_leave":staff_leave}
    return render(request, 'Hod/staff_leave.html',context)

@login_required(login_url="/")
def STAFF_APPROVE_LEAVE(request,id,status):
    leave = Staff_Leave.objects.get(id=id)
    leave.status = int(status)
    leave.save()
    messages.success(request, "Leave status changed successfully")
    return redirect('staff_leave_view')

@login_required(login_url="/")
def REPLY_STAFF_FEEDBACK(request):
    staff_feedback =Staff_Feedback.objects.all().order_by('-id')
    context = {'staff_feedback':staff_feedback}
    return render(request, 'Hod/staff_feedback.html',context)

@login_required(login_url="/")
def STAFF_FEEDBACK_SAVE(request):
    if request.method == "POST":
        feedback_id = request.POST.get('feedback_id')
        feedback    = request.POST.get('feedback_reply')

        feedback_obj = Staff_Feedback.objects.get(id=feedback_id)
        feedback_obj.feedback_reply = feedback
        feedback_obj.save()

        messages.success(request, "Feedback reply sent successfully")
        return redirect('staff_feedback_reply')

