from django.shortcuts import render,redirect,HttpResponse
from app.email import EmailBackEnd
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages

from django.conf import settings
import pyotp
import qrcode
import base64
import io

from app.models import CustomUser
from django.contrib.auth import update_session_auth_hash

#Login Required Decorator
from django.contrib.auth.decorators import login_required

def BASE(request):
    return render(request, "base.html")

def LOGIN_PAGE(request):
    return render(request, "login.html")

def doLogin(request):
    if request.method == "POST":
        user = EmailBackEnd.authenticate(request,username=request.POST.get('email'),password=request.POST.get('password'))
        if user!=None:
            if user.mfa_enabled:
                request.session["pre_2fa_user_id"] = user.id
                return redirect("login_2fa_verify")

            login(request,user)
            user_type = user.user_type
            if user_type == "1":
                return redirect('hod_home')
            elif user_type == "2":
                return redirect('staff_home')
            elif user_type == '3':
                return HttpResponse("This is Student Section")
            else:
                #Message
                messages.error(request,"Email and Password does not match!")
                return redirect('login')
        else:
            #Message
            messages.error(request,"Invalid credential")
            return redirect('login')

def doLogout(request):
    logout(request)
    return redirect('login')

@login_required(login_url='/')
def PROFILE(request):
    user = CustomUser.objects.get(id=request.user.id)
    context = {
        'user':user
    }
    return render(request,'profile.html',context)

@login_required(login_url='/')
def PROFILE_UPDATE(request):
    if request.method == "POST":
        profile_pic = request.FILES.get('profile_pic')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        password = request.POST.get('password')
        try:
            customuser = CustomUser.objects.get(id=request.user.id)
            customuser.first_name = first_name
            customuser.last_name = last_name

            if profile_pic!=None and profile_pic!="":
                customuser.profile_pic = profile_pic

            if password!=None and password!="":
                customuser.set_password(password)

            customuser.save()
            if password != None and password != "":
                update_session_auth_hash(request, customuser)

            messages.success(request,"Your profile has been updated successfully")
            return redirect('profile')
        except:
            messages.error(request,"Fail to update your profile")

    return render(request,'profile.html')


def enable_2fa(request):
    user = request.user

    if user.mfa_enabled:
        messages.info(request, "2FA already enabled.")
        return redirect("profile")

    user.mfa_secret = pyotp.random_base32()
    user.mfa_enabled = True
    user.save(update_fields=["mfa_enabled", "mfa_secret"])

    return redirect("setup_2fa")

def setup_2fa(request):
    user = request.user
    #user.refresh_from_db()

    if not user.mfa_enabled or not user.mfa_secret:
        messages.error(request, "2FA not enabled.")
        return redirect("profile")

    totp = pyotp.TOTP(user.mfa_secret)
    otp_uri = totp.provisioning_uri(
        name=user.email,
        issuer_name="NETBUDDY"
    )

    qr = qrcode.make(otp_uri)
    buffer = io.BytesIO()
    qr.save(buffer, format="PNG")
    qr_code = base64.b64encode(buffer.getvalue()).decode()

    return render(request, "setup_2fa.html", {"qr_code": qr_code})

def verify_2fa_setup(request):
    user = request.user

    if request.method == "POST":
        otp = request.POST.get("otp_code")  # <-- match your HTML

        if not otp:
            messages.error(request, "OTP is required.")
            return render(request, "verify_2fa.html")

        totp = pyotp.TOTP(user.mfa_secret)

        if totp.verify(otp, valid_window=2):
            messages.success(request, "2FA setup complete!")
            return redirect("profile")
        else:
            messages.error(request, "Invalid OTP.")

    return render(request, "verify_2fa.html")

def disable_2fa(request):
    user = request.user

    user.mfa_enabled = False
    user.mfa_secret = None
    user.save(update_fields=["mfa_enabled", "mfa_secret"])

    messages.success(request, "2FA disabled.")
    return redirect("profile")

def mfa_setup(request):
    user = request.user
    #user.refresh_from_db()

    if not user.mfa_enable or not user.mfa_secret:
        messages.error(request, "2FA not enabled.")
        return redirect("profile")

    otp_uri = pyotp.TOTP(user.mfa_secret).provisioning_uri(
        name=user.email,
        issuer_name="SCHOOL_JAY"
    )

    qr = qrcode.make(otp_uri)
    buffer = io.BytesIO()
    qr.save(buffer, format="PNG")
    qr_code = base64.b64encode(buffer.getvalue()).decode()

    return render(request, "mfa_setup.html", {"qr_code": qr_code})

def login_2fa_verify(request):
    user_id = request.session.get("pre_2fa_user_id")
    if not user_id:
        return redirect("login")

    user = CustomUser.objects.get(id=user_id)
    if request.method == "POST":
        otp = request.POST.get("otp_code").strip()
        totp = pyotp.TOTP(user.mfa_secret)

        print("Current OTP from server:", totp.now())
        print("Entered OTP:", otp)
        try:
            if totp.verify(otp, valid_window=1):
                login(request, user)
                del request.session["pre_2fa_user_id"]
                messages.success(request, "MFA verify Successfully.")
                return redirect("hod_home")
            else:
                messages.error(request, "Invalid OTP.")
        except Exception as e:
            print(e)
            messages.error(request, "Something went wrong.")

    return render(request, "login_2fa_verify.html")