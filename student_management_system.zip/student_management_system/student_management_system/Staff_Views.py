from django.shortcuts import redirect,render,HttpResponse,get_object_or_404
from django.contrib.auth.decorators import login_required
from app.models import Course,Session_Year,Student,Staff,Subject,Staff_Notification,Staff_Leave,Staff_Feedback

from django.contrib import messages
from app.models import CustomUser

def HOME(request):
    return render(request,"Staff/home.html")

def NOTIFICATION(request):
    staff = Staff.objects.filter(admin=request.user.id)
    for i in staff:
        staff_id = i.id

    notification = Staff_Notification.objects.filter(staff_id = staff_id)
    context = {'notification':notification}
    return render(request,"Staff/notification.html",context)

def STAFF_NOTIFICATION_MARK_DONE(request,status):
    notify = Staff_Notification.objects.get(id=status)
    notify.status = 1
    notify.save()
    messages.success(request, "Notification read successfully")
    return redirect("notification")

def STAFF_APPLY_LEAVE(request):
    staff = Staff.objects.filter(admin=request.user.id)
    for i in staff:
        staff_id = i.id
    staff_leave = Staff_Leave.objects.filter(staff_id=staff_id)
    context = {"staff_leave":staff_leave}
    return render(request,"Staff/apply_leave.html",context)

def STAFF_APPLY_LEAVE_SAVE(request):
    if request.method == "POST":
        leave_date = request.POST.get('date')
        leave_msg = request.POST.get('message')
        staff = Staff.objects.get(admin=request.user.id)
        leave_obj = Staff_Leave(
            staff_id = staff,
            message = leave_msg,
            date = leave_date
        )
        leave_obj.save()
        messages.success(request, "Leave added successfully")
        return redirect('staff_apply_leave')

def STAFF_FEEDBACK(request):
    if request.method == "POST":
        staff = Staff.objects.get(admin = request.user.id)
        feedback = request.POST.get('feedback')
        feedback_obj = Staff_Feedback(
            staff_id = staff,
            feedback=feedback,
            feedback_reply=''
        )
        feedback_obj.save()
        messages.success(request, "Feedback sent successfully")
        return redirect('staff_feedback')
    else:
        staff_id = Staff.objects.get(admin=request.user.id)
        feeback_history = Staff_Feedback.objects.filter(staff_id=staff_id)
        context = {'feeback_history':feeback_history}

    return render(request, "Staff/feedback.html",context)

